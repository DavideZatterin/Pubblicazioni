CREATE DATABASE ToysGroup;

USE ToysGroup;

--Creazione delle tabelle ed impostazione delle chiavi

CREATE TABLE Region
            (
			 RegionKey INT PRIMARY KEY,
			 RegionName VARCHAR (25),
			 CountryName VARCHAR (25),
			 ContinentName VARCHAR (25)
			 );


CREATE TABLE Product
            (
			 ProductKey INT PRIMARY KEY,
			 ProductName VARCHAR (25),
			 CategoryName VARCHAR (25),
			 ParentCategoryNameKey INT,
			 UnitPrice DECIMAL (10,2)
			 );

CREATE TABLE Sales
            (
			 SalesOrderID INT PRIMARY KEY,
			 SalesOrderLineNumber INT,
			 SalesOrderNumber VARCHAR (35),
			 OrderDate DATE,
			 UnitPrice DECIMAL (10,2),
			 Quantity INT,
			 ProductKey INT,
			 SalesAmount AS Quantity * UnitPrice,
			 RegionKey INT,
			 FOREIGN KEY (ProductKey) REFERENCES Product(ProductKey),
			 FOREIGN KEY (RegionKey) REFERENCES Region(RegionKey)
			 );


--popolamento delle tabelle


INSERT INTO Region (RegionKey, RegionName, CountryName, ContinentName)
VALUES
  (1, 'North Europe', 'England', 'Europe'),
  (2, 'North Europe', 'Finland', 'Europe'),
  (3, 'North Europe', 'Sweden', 'Europe'),
  (4, 'North Europe', 'Norwey', 'Europe'),
  (5, 'South Europe', 'Italy', 'Europe'),
  (6, 'South Europe', 'Greece', 'Europe'),
  (7, 'South Europe', 'Albany', 'Europe'),
  (8, 'South Europe', 'Croatia', 'Europe'),
  (9, 'East Europe', 'Romania', 'Europe'),
  (10, 'East Europe', 'Hungary', 'Europe'),
  (11, 'East Europe', 'Ukraine', 'Europe'),
  (12, 'East Europe', 'Bulgaria', 'Europe'),
  (13, 'West Europe', 'Spain', 'Europe'),
  (14, 'West Europe', 'Portugal', 'Europe'),
  (15, 'West Europe', 'France', 'Europe'),
  (16, 'Central Europe', 'Germany', 'Europe'),
  (17, 'Central Europe', 'Holland', 'Europe'),
  (18, 'Central Europe', 'Poland', 'Europe'),
  (19, 'Central Europe', 'Belgium', 'Europe'),
  (20, 'North America', 'Nebraska', 'North America'),
  (21, 'North America', 'Missouri', 'North America'),
  (22, 'North America', 'Iowa', 'North America'),
  (23, 'North America', 'Colorado', 'North America'),
  (24, 'South America', 'Brazil', 'South America'),
  (25, 'South America', 'Per�', 'South America'),
  (26, 'South America', 'Cile', 'South America'),
  (27, 'South America', 'Colombia', 'South America'),
  (28, 'East America', 'New York', 'North America'),
  (29, 'East America', 'Pennsylvania', 'North America'),
  (30, 'East America', 'Virginia', 'North America'),
  (31, 'East America', 'Kentucky', 'North America'),
  (32, 'West America', 'California', 'North America'),
  (33, 'West America', 'Nevada', 'North America'),
  (34, 'West America', 'Oregon', 'North America'),
  (35, 'West America', 'Arizona', 'North America'),
  (36, 'Central America', 'Nicaragua', 'Central America'),
  (37, 'Central America', 'Costa Rica', 'Central America'),
  (38, 'Central America', 'Panama', 'Central America'),
  (39, 'Central America', 'Guatemala', 'Central America')
 
 

 
 INSERT INTO Sales(SalesOrderID, SalesOrderNumber, SalesOrderLineNumber, OrderDate, UnitPrice, Quantity, ProductKey, RegionKey)
 VALUES
       (001,24-001,1,'2024-01-03',15.99,1,4,38),
	   (002,24-001,2,'2024-01-03',5.99,1,1,38),
	   (003,24-002,1,'2024-01-08',21.50,2,3,12),
	   (004,24-003,1,'2024-01-15',5.99,1,1,27),
	   (005,24-003,2,'2024-01-15',14.15,4,8,27),
	   (006,24-003,3,'2024-01-15',16.50,1,5,27),
	   (007,23-001,1,'2023-01-22',9.99,2,2,16),
	   (008,23-001,2,'2023-01-22',16.50,1,5,16),
	   (009,23-002,1,'2023-02-14',5.99,2,1,3),
	   (010,23-003,1,'2023-03-30',14.15,1,8,9),
	   (011,23-004,1,'2023-04-21',16.50,1,5,25),
	   (012,23-005,1,'2023-05-04',15.99,2,4,17),
	   (013,23-005,2,'2023-05-04',5.99,2,1,17),
	   (014,23-006,1,'2023-06-04',32.00,1,9,15),
	   (015,23-007,1,'2023-07-11',13.00,1,12,4),
	   (016,23-008,1,'2023-08-12',10.00,1,11,7),
	   (017,23-009,1,'2023-09-10',9.99,2,2,30),
	   (018,23-009,2,'2023-09-10',6.50,2,10,30),
	   (019,23-009,3,'2023-09-10',10.00,3,11,30),
	   (020,23-010,1,'2023-10-19',21.50,1,3,26)


INSERT INTO Product(ProductKey, ProductName, CategoryName, ParentCategoryNameKey, UnitPrice)
VALUES 
      (1,'Carte da Scala','Giochi da Tavolo',1,5.99),
	  (2,'Carte da Poker','Giochi da Tavolo',1,9.99),
	  (3,'Risiko Original','Giochi da Tavolo',1,21.50),
	  (4,'Scacchi','Giochi da Tavolo',1,15.99),
	  (5,'Palla da Calcio','Giochi Outdoor',2,16.50),
	  (6,'Set Bocce','Giochi Outdoor',2,41.99),
	  (7,'Bicicletta da Bambini','Giochi Outdoor',2,49.90),
	  (8,'Pistola Acqua','Giochi con Acqua',3,14.15),
	  (9,'Fucile ad Acqua','Giochi con Acqua',3,32.00),
	  (10,'Molla elastica','Giochi Acrobatici',4,6.50),
	  (11,'YoYo','Giochi Acrobatici',4,10.00),
	  (12,'Diablo','Giochi Acrobatici',4,13.00)

--verifica dell'inserimento dei valori nelle tabelle

	  SELECT *
	  FROM Product

	  SELECT *
	  FROM Sales

	  SELECT *
	  FROM Region


-- Verifica univocit� dei campi PK


SELECT COUNT(*), SalesOrderID
FROM Sales
GROUP BY SalesOrderID
HAVING COUNT(*) > 1


SELECT COUNT(*), ProductKey
FROM Product
GROUP BY ProductKey
HAVING COUNT(*) > 1


SELECT COUNT(*), RegionKey
FROM Region
GROUP BY RegionKey
HAVING COUNT(*) > 1

--Elenco transazioni + verifica 180 giorni


SELECT SalesOrderNumber, OrderDate, ProductName, CategoryName, CountryName, RegionName,
CASE WHEN DATEDIFF(DAY, OrderDate, GETDATE()) > 180 THEN 'TRUE' ELSE 'FALSE' END AS CheckDate
FROM Sales AS s
INNER JOIN Product AS p
ON s.ProductKey = p.ProductKey
INNER JOIN Region AS r
ON r.RegionKey = s.RegionKey


--Elenco venduti + fatturato tot anno


SELECT s.ProductKey, SUM(s.SalesAmount) AS SalesAmount, YEAR(s.OrderDate) AS LastYear
FROM Product AS p
INNER JOIN Sales AS s
ON s.ProductKey = p.ProductKey
GROUP BY s.ProductKey, YEAR(s.OrderDate)
ORDER BY s.ProductKey 


--Tot fatturato per stato per anno, decrescente


SELECT r.CountryName, SUM(s.SalesAmount) AS SalesAmount, YEAR(s.OrderDate) AS SalesYear
FROM Region AS r
JOIN Sales AS s
ON s.RegionKey = r.RegionKey
GROUP BY r.CountryName, YEAR(s.OrderDate)
ORDER BY SalesAmount DESC


--Articoli maggiormente richiesti


SELECT CategoryName, COUNT(*) AS TotalCount
FROM Product
WHERE ProductKey IN
                 (
				  SELECT ProductKey
				  FROM Sales)
GROUP BY CategoryName


--prodotti invenduti


SELECT p.ProductName, s.Quantity
FROM Product AS p
LEFT JOIN Sales AS s
ON p.ProductKey = s.ProductKey
WHERE s.Quantity IS NULL
ORDER BY s.Quantity


SELECT p.ProductName, s.SalesAmount
FROM Product AS p
LEFT JOIN Sales AS s
ON p.ProductKey = s.ProductKey
WHERE s.SalesAmount IS NULL
ORDER BY s.SalesAmount


--elenco prodotti + ultima data di vendita


SELECT F1.OrderDate, F1.ProductKey
FROM Sales AS F1
WHERE OrderDate = (
                      SELECT MAX(OrderDate)
                      FROM Sales AS F2
                      WHERE F1.ProductKey = F2.ProductKey)
GROUP BY F1.ProductKey, F1.OrderDate
ORDER BY F1.ProductKey;


--Creare una vista sui prodotti


CREATE VIEW VW_DZ_Product AS (
SELECT ProductKey, ProductName, CategoryName
FROM Product);


--Creare vista area geografica


CREATE VIEW VW_DZ_InfoGeografiche AS (
SELECT CountryName, RegionName, ContinentName, RegionKey
FROM Region);


--Creata vista per esercizio opzionale


CREATE VIEW VW_DZ_InfoSales AS (
SELECT SalesOrderID, SalesOrderLineNumber, SalesOrderNumber, OrderDate, UnitPrice, Quantity, SalesAmount, ProductKey, RegionKey
FROM Sales);